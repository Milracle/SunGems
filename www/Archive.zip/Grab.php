<!DOCTYPE html>
<html>
<body>
<form action="download.php" method="post">
          <select name="buyer" id="buyer" >
              <option value="">Select User</option>
              <option value="Haresh">Haresh</option>
              <option value="Kirmal">Kirmal</option>
              <option value="Mahesh">Mahesh</option>
              <option value="Tushar">Tushar</option>
              <option value="Virendra">Virendra</option>
              <option value="Vishal">Vishal</option>
              <option value="Yogesh">Yogesh</option>
          </select>
    
<textarea name="string" rows="10" cols="30"></textarea>
  <br>
<input type="submit">
</form>

</body>
</html>
